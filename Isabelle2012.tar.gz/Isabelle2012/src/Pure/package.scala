/*  Title:      Pure/package.scala
    Module:     PIDE
    Author:     Makarius

Toplevel isabelle package.
*/

package object isabelle extends isabelle.Basic_Library
{
}

