/*  Title:      Pure/package.scala
    Author:     Makarius

Toplevel isabelle package.
*/

package object isabelle extends isabelle.Basic_Library
{
}

