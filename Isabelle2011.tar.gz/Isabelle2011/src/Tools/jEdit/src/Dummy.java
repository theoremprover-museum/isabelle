/* dummy class to make ant javadoc work */
package isabelle;
public class Dummy { }
