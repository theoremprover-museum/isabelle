/*  Title:      Pure/System/distribution.scala
    Author:     Makarius

The Isabelle system distribution -- filled-in by makedist.
*/

package isabelle


object Distribution
{
  val version = "Isabelle2016-1: December 2016"
  val is_identified = true
  val is_official = true
}
