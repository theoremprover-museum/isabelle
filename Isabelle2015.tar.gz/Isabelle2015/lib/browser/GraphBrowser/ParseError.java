package GraphBrowser;

class ParseError extends Exception {
	public ParseError(String s) { super(s); }
}
